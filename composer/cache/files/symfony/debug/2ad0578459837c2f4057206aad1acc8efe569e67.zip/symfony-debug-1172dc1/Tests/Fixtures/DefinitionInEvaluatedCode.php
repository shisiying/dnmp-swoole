<?php

namespace Symfony\Component\Debug\Tests\Fixtures;

eval('
    namespace Symfony\Component\Debug\Tests\Fixtures;

    class DefinitionInEvaluatedCode
    {
    }
');
