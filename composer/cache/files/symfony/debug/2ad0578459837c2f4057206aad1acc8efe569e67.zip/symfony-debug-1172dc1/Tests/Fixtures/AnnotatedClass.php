<?php

namespace Symfony\Component\Debug\Tests\Fixtures;

class AnnotatedClass
{
    /**
     * @deprecated since version 3.4.
     */
    public function deprecatedMethod()
    {
    }
}
