<?php

class AssertionError extends Error
{
}
