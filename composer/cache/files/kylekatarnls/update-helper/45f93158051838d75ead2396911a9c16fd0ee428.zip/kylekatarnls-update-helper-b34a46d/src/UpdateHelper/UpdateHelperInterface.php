<?php

namespace UpdateHelper;

interface UpdateHelperInterface
{
    public function check(UpdateHelper $helper);
}
