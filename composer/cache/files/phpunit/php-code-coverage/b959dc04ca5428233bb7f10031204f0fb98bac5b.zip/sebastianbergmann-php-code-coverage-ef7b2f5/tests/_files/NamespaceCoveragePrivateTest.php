<?php
class NamespaceCoveragePrivateTest extends PHPUnit_Framework_TestCase
{
    /**
     * @covers Foo\CoveredClass::<private>
     */
    public function testSomething()
    {
        $o = new Foo\CoveredClass;
        $o->publicMethod();
    }
}
