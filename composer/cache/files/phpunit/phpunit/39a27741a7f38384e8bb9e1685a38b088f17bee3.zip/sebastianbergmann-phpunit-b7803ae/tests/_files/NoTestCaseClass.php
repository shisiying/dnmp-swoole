<?php
class NoTestCaseClass
{
}
